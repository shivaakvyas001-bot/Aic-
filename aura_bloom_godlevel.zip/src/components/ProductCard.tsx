import { Link } from "react-router-dom";
import { Heart, ShoppingBag, Eye } from "lucide-react";
import { Product } from "@/data/products";
import { useCart } from "@/context/CartContext";
import { toast } from "sonner";

interface Props {
  product: Product;
}

const ProductCard = ({ product }: Props) => {
  const { addItem } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addItem(product, product.sizes[1] || product.sizes[0]);
    toast.success(`${product.name} added to cart`);
  };

  return (
    <Link to={`/product/${product.id}`} className="group block">
      <div className="relative overflow-hidden rounded-xl bg-muted aspect-[3/4] card-shadow group-hover:card-shadow-hover transition-shadow duration-300">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          width={800}
          height={1024}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        {/* Overlay on hover */}
        <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/10 transition-colors duration-300" />
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {product.isNew && (
            <span className="bg-secondary text-secondary-foreground text-[10px] font-sans font-semibold uppercase tracking-wider px-2.5 py-1 rounded-full">
              New
            </span>
          )}
          {product.isSale && (
            <span className="bg-primary text-primary-foreground text-[10px] font-sans font-semibold uppercase tracking-wider px-2.5 py-1 rounded-full">
              Sale
            </span>
          )}
        </div>
        {/* Quick actions */}
        <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 translate-x-2 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0">
          <button className="w-9 h-9 rounded-full bg-background/90 backdrop-blur-sm flex items-center justify-center text-foreground hover:bg-primary hover:text-primary-foreground transition-colors card-shadow">
            <Heart size={16} />
          </button>
          <button className="w-9 h-9 rounded-full bg-background/90 backdrop-blur-sm flex items-center justify-center text-foreground hover:bg-secondary hover:text-secondary-foreground transition-colors card-shadow">
            <Eye size={16} />
          </button>
          <button
            onClick={handleAddToCart}
            className="w-9 h-9 rounded-full bg-background/90 backdrop-blur-sm flex items-center justify-center text-foreground hover:bg-primary hover:text-primary-foreground transition-colors card-shadow"
          >
            <ShoppingBag size={16} />
          </button>
        </div>
        {/* Quick add bar */}
        <div className="absolute bottom-0 left-0 right-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <button
            onClick={handleAddToCart}
            className="w-full py-3 bg-primary text-primary-foreground font-sans text-xs font-semibold uppercase tracking-wider hover:bg-primary/90 transition-colors"
          >
            Quick Add to Cart
          </button>
        </div>
      </div>
      <div className="mt-3 px-1">
        <h3 className="font-sans text-sm font-medium text-foreground group-hover:text-primary transition-colors">
          {product.name}
        </h3>
        <div className="flex items-center gap-2 mt-1">
          <span className="font-sans text-sm font-semibold text-foreground">₹{product.price.toLocaleString()}</span>
          {product.originalPrice && (
            <span className="font-sans text-xs text-muted-foreground line-through">
              ₹{product.originalPrice.toLocaleString()}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1 mt-1">
          <span className="text-primary text-xs">★</span>
          <span className="font-sans text-xs text-muted-foreground">{product.rating} ({product.reviews})</span>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
