
import { motion } from "framer-motion";
import { useState } from "react";

export default function TiltCard({ children }: any) {
  const [style, setStyle] = useState({});

  const handleMove = (e:any) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const rotateX = ((y / rect.height) - 0.5) * -20;
    const rotateY = ((x / rect.width) - 0.5) * 20;

    setStyle({
      transform: `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.05)`
    });
  };

  return (
    <motion.div
      onMouseMove={handleMove}
      onMouseLeave={() => setStyle({ transform: "perspective(1000px) rotateX(0) rotateY(0) scale(1)" })}
      style={style}
      className="transition-all duration-300"
    >
      {children}
    </motion.div>
  );
}
