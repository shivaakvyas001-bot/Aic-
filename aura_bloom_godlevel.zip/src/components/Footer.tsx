import { Link } from "react-router-dom";
import { Instagram, Facebook, Twitter } from "lucide-react";

const Footer = () => (
  <footer className="bg-foreground text-primary-foreground">
    <div className="container mx-auto px-4 py-16">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
        <div>
          <h3 className="font-serif text-2xl mb-4 gradient-primary-text">AIC</h3>
          <p className="text-sm opacity-70 leading-relaxed font-sans">
            Bold fashion for the modern soul. Where creativity meets confidence.
          </p>
          <div className="flex gap-4 mt-6">
            <a href="#" className="opacity-70 hover:opacity-100 transition-opacity"><Instagram size={20} /></a>
            <a href="#" className="opacity-70 hover:opacity-100 transition-opacity"><Facebook size={20} /></a>
            <a href="#" className="opacity-70 hover:opacity-100 transition-opacity"><Twitter size={20} /></a>
          </div>
        </div>
        {[
          { title: "Shop", links: ["Women", "Men", "Accessories", "New Arrivals", "Sale"] },
          { title: "Help", links: ["FAQ", "Shipping", "Returns", "Size Guide", "Contact"] },
          { title: "Company", links: ["About Us", "Careers", "Sustainability", "Press", "Terms"] },
        ].map((col) => (
          <div key={col.title}>
            <h4 className="font-serif text-lg mb-4">{col.title}</h4>
            <ul className="space-y-2 font-sans text-sm">
              {col.links.map((link) => (
                <li key={link}>
                  <Link to="/shop" className="opacity-70 hover:opacity-100 transition-opacity">{link}</Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-primary-foreground/10 mt-12 pt-8 text-center font-sans text-xs opacity-50">
        © 2026 AIC. All rights reserved.
      </div>
    </div>
  </footer>
);

export default Footer;
