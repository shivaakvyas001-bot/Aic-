import { MessageCircle } from "lucide-react";

const WhatsAppButton = () => {
  return (
    <a
      href="https://wa.me/919999999999?text=Hi! I need help with my order on AIC"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-4 right-4 z-40 w-14 h-14 rounded-full bg-[hsl(142,70%,45%)] text-primary-foreground flex items-center justify-center card-shadow hover:scale-110 transition-all"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle size={24} />
    </a>
  );
};

export default WhatsAppButton;
