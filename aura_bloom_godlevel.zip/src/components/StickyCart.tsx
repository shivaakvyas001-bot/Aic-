import { Link } from "react-router-dom";
import { ShoppingBag } from "lucide-react";
import { useCart } from "@/context/CartContext";

const StickyCart = () => {
  const { totalItems, totalPrice } = useCart();

  if (totalItems === 0) return null;

  return (
    <Link
      to="/cart"
      className="fixed bottom-20 right-4 z-40 flex items-center gap-3 px-5 py-3 rounded-full gradient-primary text-primary-foreground font-sans text-sm font-semibold card-shadow hover:scale-105 transition-all glow-orange"
    >
      <ShoppingBag size={18} />
      <span>{totalItems} items</span>
      <span className="border-l border-primary-foreground/30 pl-3">₹{totalPrice.toLocaleString()}</span>
    </Link>
  );
};

export default StickyCart;
