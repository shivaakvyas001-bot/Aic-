
import { motion } from "framer-motion";

export default function Floating({ children }: any) {
  return (
    <motion.div
      animate={{ y: [0, -10, 0] }}
      transition={{ repeat: Infinity, duration: 3 }}
    >
      {children}
    </motion.div>
  );
}
