import { useState } from "react";
import { Link } from "react-router-dom";
import { Search, ShoppingBag, Heart, User, Menu, X } from "lucide-react";
import { useCart } from "@/context/CartContext";

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { totalItems } = useCart();

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
      {/* Top bar */}
      <div className="gradient-primary text-center py-1.5 px-4">
        <p className="text-xs font-sans tracking-widest text-primary-foreground uppercase">
          Free shipping on orders over ₹2,999 — Use code AIC20
        </p>
      </div>

      <nav className="container mx-auto flex items-center justify-between px-4 py-4 lg:py-5">
        {/* Mobile menu btn */}
        <button onClick={() => setMobileOpen(!mobileOpen)} className="lg:hidden text-foreground">
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        {/* Logo */}
        <Link to="/" className="font-serif text-2xl lg:text-3xl tracking-wide text-foreground">
          <span className="gradient-primary-text font-bold">AIC</span>
        </Link>

        {/* Desktop links */}
        <ul className="hidden lg:flex items-center gap-8 font-sans text-sm tracking-wide uppercase text-muted-foreground">
          {["New Arrivals", "Women", "Men", "Accessories"].map((item) => (
            <li key={item}>
              <Link
                to="/shop"
                className="relative py-1 transition-colors hover:text-primary after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-primary after:transition-all hover:after:w-full"
              >
                {item}
              </Link>
            </li>
          ))}
        </ul>

        {/* Icons */}
        <div className="flex items-center gap-4">
          <button className="text-muted-foreground hover:text-primary transition-colors">
            <Search size={20} />
          </button>
          <Link to="/cart" className="text-muted-foreground hover:text-primary transition-colors hidden sm:block">
            <Heart size={20} />
          </Link>
          <Link to="/admin" className="text-muted-foreground hover:text-primary transition-colors hidden sm:block">
            <User size={20} />
          </Link>
          <Link to="/cart" className="relative text-muted-foreground hover:text-primary transition-colors">
            <ShoppingBag size={20} />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-sans font-semibold">
                {totalItems}
              </span>
            )}
          </Link>
        </div>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-background border-t border-border animate-fade-in">
          <ul className="flex flex-col py-4 px-6 gap-4 font-sans text-sm uppercase tracking-wide text-muted-foreground">
            {["New Arrivals", "Women", "Men", "Accessories"].map((item) => (
              <li key={item}>
                <Link to="/shop" onClick={() => setMobileOpen(false)} className="block py-2 hover:text-primary transition-colors">
                  {item}
                </Link>
              </li>
            ))}
            <li>
              <Link to="/admin" onClick={() => setMobileOpen(false)} className="block py-2 hover:text-primary transition-colors">
                Admin Panel
              </Link>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
};

export default Navbar;
