import product1 from "@/assets/product-1.jpg";
import product2 from "@/assets/product-2.jpg";
import product3 from "@/assets/product-3.jpg";
import product4 from "@/assets/product-4.jpg";
import product5 from "@/assets/product-5.jpg";
import product6 from "@/assets/product-6.jpg";
import product7 from "@/assets/product-7.jpg";
import product8 from "@/assets/product-8.jpg";

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  sizes: string[];
  colors: string[];
  rating: number;
  reviews: number;
  description: string;
  isNew?: boolean;
  isSale?: boolean;
  occasion?: string[];
  mood?: string[];
}

export const products: Product[] = [
  {
    id: "1",
    name: "Rosé Silk Blouse",
    price: 189,
    originalPrice: 249,
    image: product1,
    category: "Women",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Pink", "White", "Navy"],
    rating: 4.8,
    reviews: 124,
    description: "Luxurious silk blouse with balloon sleeves and a refined silhouette. Perfect for both casual and formal occasions.",
    isNew: true,
    isSale: true,
    occasion: ["Party", "Casual"],
    mood: ["Elegant", "Minimal"],
  },
  {
    id: "2",
    name: "Midnight Structured Blazer",
    price: 345,
    image: product2,
    category: "Men",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["Navy", "Black", "Charcoal"],
    rating: 4.9,
    reviews: 89,
    description: "Impeccably tailored blazer in premium wool blend. Sharp shoulders and a modern slim fit for the discerning gentleman.",
    occasion: ["Party", "Wedding"],
    mood: ["Bold", "Elegant"],
  },
  {
    id: "3",
    name: "Emerald Flowing Maxi",
    price: 425,
    image: product3,
    category: "Women",
    sizes: ["XS", "S", "M", "L"],
    colors: ["Emerald", "Burgundy", "Black"],
    rating: 4.7,
    reviews: 67,
    description: "Breathtaking floor-length gown in flowing chiffon. Deep V-neckline and gathered waist create an effortlessly elegant silhouette.",
    isNew: true,
    occasion: ["Wedding", "Party"],
    mood: ["Elegant", "Bold"],
  },
  {
    id: "4",
    name: "Royal Heritage Kurta",
    price: 275,
    originalPrice: 350,
    image: product4,
    category: "Men",
    sizes: ["S", "M", "L", "XL"],
    colors: ["Ivory", "Sky Blue", "Sage"],
    rating: 4.6,
    reviews: 156,
    description: "Handcrafted ivory kurta with intricate gold zari embroidery. A timeless piece that bridges tradition and contemporary style.",
    isSale: true,
    occasion: ["Wedding", "Party"],
    mood: ["Elegant", "Bold"],
  },
  {
    id: "5",
    name: "Lavender Wrap Dress",
    price: 295,
    image: product5,
    category: "Women",
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Lavender", "Blush", "Champagne"],
    rating: 4.5,
    reviews: 93,
    description: "Elegant wrap dress in luxurious silk with a flattering tie waist. The perfect day-to-night transition piece.",
    occasion: ["Casual", "Party"],
    mood: ["Minimal", "Elegant"],
  },
  {
    id: "6",
    name: "Coral Ruffle Cocktail Dress",
    price: 375,
    originalPrice: 450,
    image: product6,
    category: "Women",
    sizes: ["XS", "S", "M", "L"],
    colors: ["Coral", "Fuchsia", "Peach"],
    rating: 4.8,
    reviews: 78,
    description: "Show-stopping cocktail dress with dramatic ruffle detailing. A bold statement piece for your most special occasions.",
    isSale: true,
    occasion: ["Party", "Wedding"],
    mood: ["Bold", "Elegant"],
  },
  {
    id: "7",
    name: "Ivory Tailored Trousers",
    price: 195,
    image: product7,
    category: "Men",
    sizes: ["28", "30", "32", "34", "36"],
    colors: ["Ivory", "Khaki", "Navy"],
    rating: 4.4,
    reviews: 112,
    description: "Perfectly tailored linen trousers with a relaxed yet refined fit. Cuffed hem adds a sophisticated finishing touch.",
    isNew: true,
    occasion: ["Casual"],
    mood: ["Minimal"],
  },
  {
    id: "8",
    name: "Sapphire Statement Set",
    price: 165,
    image: product8,
    category: "Accessories",
    sizes: ["One Size"],
    colors: ["Blue", "Ruby", "Emerald"],
    rating: 4.9,
    reviews: 201,
    description: "Stunning sapphire and gold statement necklace with matching earrings. Handcrafted with precision-cut stones.",
    occasion: ["Wedding", "Party"],
    mood: ["Bold", "Elegant"],
  },
];
