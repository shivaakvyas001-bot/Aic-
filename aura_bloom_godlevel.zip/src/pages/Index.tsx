import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, ChevronLeft, ChevronRight, Play, Sparkles, MessageCircle } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import StickyCart from "@/components/StickyCart";
import WhatsAppButton from "@/components/WhatsAppButton";
import { products } from "@/data/products";

import hero1 from "@/assets/hero-1.jpg";
import hero2 from "@/assets/hero-2.jpg";
import heroVideoAsset from "@/assets/hero-video.mp4.asset.json";
import catWomen from "@/assets/category-women.jpg";
import catMen from "@/assets/category-men.jpg";
import catAccessories from "@/assets/category-accessories.jpg";
import catNew from "@/assets/category-new.jpg";

const heroSlides = [
  { image: hero1, title: "Bold New\nCollection", subtitle: "Fashion that speaks confidence", cta: "Shop Now", isVideo: false, video: "" },
  { image: "", title: "Walk in\nConfidence", subtitle: "Premium fashion crafted for the modern you", cta: "Shop Now", isVideo: true, video: heroVideoAsset.url },
  { image: hero2, title: "Curated\nAccessories", subtitle: "Statement pieces that define your style", cta: "Explore", isVideo: false, video: "" },
];

const categories = [
  { name: "Women", image: catWomen, color: "from-primary/60" },
  { name: "Men", image: catMen, color: "from-secondary/60" },
  { name: "Accessories", image: catAccessories, color: "from-accent/60" },
  { name: "New Arrivals", image: catNew, color: "from-primary/60" },
];

const collections = [
  "Summer Luxe", "Wedding Season", "Street Style", "Office Edit", "Weekend Vibes",
  "Party Ready", "Minimal Chic", "Bold & Beautiful", "Festival Mode", "Classic Cuts",
];

const Index = () => {
  const [slide, setSlide] = useState(0);
  const [email, setEmail] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setInterval(() => setSlide((s) => (s + 1) % heroSlides.length), 5000);
    return () => clearInterval(timer);
  }, []);

  const recommended = products.slice(0, 4);
  const newArrivals = products.filter(p => p.isNew);
  const trending = products.sort((a, b) => b.reviews - a.reviews).slice(0, 4);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero with Video Banner */}
      <section className="relative h-[60vh] sm:h-[70vh] lg:h-[85vh] overflow-hidden">
        {heroSlides.map((s, i) => (
          <div
            key={i}
            className={`absolute inset-0 transition-opacity duration-1000 ${i === slide ? "opacity-100" : "opacity-0"}`}
          >
            {s.isVideo ? (
              <video src={s.video} autoPlay muted loop playsInline className="w-full h-full object-cover" />
            ) : (
              <img src={s.image} alt={s.title} className="w-full h-full object-cover" width={1920} height={1080} />
            )}
            <div className="absolute inset-0 bg-gradient-to-r from-foreground/40 via-foreground/20 to-transparent" />
          </div>
        ))}
        <div className="absolute inset-0 flex items-center px-4 lg:px-16">
          <div className="animate-fade-in-up max-w-2xl" key={slide}>
            <span className="inline-block px-4 py-1.5 rounded-full bg-primary/20 text-primary font-sans text-xs font-semibold uppercase tracking-wider mb-4 backdrop-blur-sm border border-primary/30">
              ✨ New Season Drop
            </span>
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-7xl text-background leading-tight whitespace-pre-line drop-shadow-lg">
              {heroSlides[slide].title}
            </h1>
            <p className="font-sans text-sm sm:text-base text-background/90 mt-4 tracking-wide max-w-md">
              {heroSlides[slide].subtitle}
            </p>
            <div className="flex gap-4 mt-8">
              <Link
                to="/shop"
                className="inline-flex items-center gap-2 px-8 py-3.5 gradient-primary text-primary-foreground font-sans text-sm font-semibold uppercase tracking-wider rounded-full hover:scale-105 transition-all duration-300 glow-orange"
              >
                {heroSlides[slide].cta}
                <ArrowRight size={16} />
              </Link>
              <button className="inline-flex items-center gap-2 px-6 py-3.5 bg-background/20 backdrop-blur-sm text-background font-sans text-sm font-semibold uppercase tracking-wider rounded-full border border-background/30 hover:bg-background/30 transition-all">
                <Play size={16} />
                Watch
              </button>
            </div>
          </div>
        </div>
        {/* Nav arrows */}
        <button onClick={() => setSlide((s) => (s - 1 + heroSlides.length) % heroSlides.length)} className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-background/20 backdrop-blur-sm flex items-center justify-center text-background hover:bg-background/40 transition-colors">
          <ChevronLeft size={22} />
        </button>
        <button onClick={() => setSlide((s) => (s + 1) % heroSlides.length)} className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-background/20 backdrop-blur-sm flex items-center justify-center text-background hover:bg-background/40 transition-colors">
          <ChevronRight size={22} />
        </button>
        {/* Dots */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
          {heroSlides.map((_, i) => (
            <button key={i} onClick={() => setSlide(i)} className={`h-2.5 rounded-full transition-all duration-300 ${i === slide ? "bg-primary w-10" : "bg-background/50 w-2.5"}`} />
          ))}
        </div>
      </section>

      {/* Auto-Scrolling Collections */}
      <section className="py-6 overflow-hidden border-b border-border bg-muted/30">
        <div className="flex animate-scroll-left" style={{ width: "max-content" }}>
          {[...collections, ...collections].map((c, i) => (
            <Link
              key={i}
              to="/shop"
              className="flex-shrink-0 px-6 py-2 mx-2 rounded-full border border-border bg-background font-sans text-sm text-muted-foreground hover:text-primary hover:border-primary transition-colors whitespace-nowrap"
            >
              {c}
            </Link>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="container mx-auto px-4 py-16 lg:py-24">
        <div className="text-center mb-12">
          <span className="font-sans text-xs uppercase tracking-[0.3em] text-primary font-semibold">Explore</span>
          <h2 className="font-serif text-3xl lg:text-5xl text-foreground mt-2">Shop by Category</h2>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {categories.map((cat) => (
            <Link key={cat.name} to="/shop" className="group relative overflow-hidden rounded-2xl aspect-[3/4] card-shadow hover:card-shadow-hover transition-shadow duration-300">
              <img src={cat.image} alt={cat.name} loading="lazy" width={800} height={1024} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className={`absolute inset-0 bg-gradient-to-t ${cat.color} to-transparent`} />
              <div className="absolute bottom-4 left-4 right-4">
                <h3 className="font-serif text-xl lg:text-2xl text-background">{cat.name}</h3>
                <span className="inline-flex items-center gap-1 font-sans text-xs text-background/80 uppercase tracking-wider group-hover:text-background transition-colors mt-1">
                  Explore <ArrowRight size={12} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Recommended For You */}
      <section className="bg-peach/30 py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles size={16} className="text-primary" />
                <span className="font-sans text-xs uppercase tracking-[0.3em] text-primary font-semibold">AI Powered</span>
              </div>
              <h2 className="font-serif text-3xl lg:text-4xl text-foreground">Recommended For You</h2>
            </div>
            <Link to="/shop" className="font-sans text-sm text-primary hover:underline uppercase tracking-wider">
              View All
            </Link>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {recommended.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* Trending */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-12">
            <div>
              <span className="font-sans text-xs uppercase tracking-[0.3em] text-secondary font-semibold">Hot Right Now</span>
              <h2 className="font-serif text-3xl lg:text-4xl text-foreground mt-2">Trending Now</h2>
            </div>
            <Link to="/shop" className="font-sans text-sm text-primary hover:underline uppercase tracking-wider">
              View All
            </Link>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {trending.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* Promo Banner */}
      <section className="relative overflow-hidden">
        <div className="gradient-primary py-16 lg:py-24 text-center px-4">
          <div className="relative z-10">
            <span className="inline-block px-4 py-1 rounded-full bg-background/20 text-primary-foreground/90 font-sans text-xs font-semibold uppercase tracking-wider mb-4">
              Limited Time
            </span>
            <h2 className="font-serif text-3xl lg:text-6xl text-primary-foreground mb-4">
              Summer Sale — Up to 40% Off
            </h2>
            <p className="font-sans text-sm text-primary-foreground/80 mb-8 max-w-lg mx-auto">
              Discover curated pieces at exceptional prices. Limited time only.
            </p>
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 px-8 py-3.5 bg-background text-foreground font-sans text-sm font-semibold uppercase tracking-wider rounded-full hover:scale-105 transition-transform card-shadow"
            >
              Shop the Sale
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* Complete The Look */}
      <section className="container mx-auto px-4 py-16 lg:py-24">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Sparkles size={16} className="text-secondary" />
            <span className="font-sans text-xs uppercase tracking-[0.3em] text-secondary font-semibold">AI Styled</span>
          </div>
          <h2 className="font-serif text-3xl lg:text-4xl text-foreground">Complete The Look</h2>
          <p className="font-sans text-sm text-muted-foreground mt-2">AI-curated outfits to inspire your next style</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { title: "Wedding Guest", items: [products[2], products[7]], mood: "Elegant & Refined" },
            { title: "Night Out", items: [products[5], products[0]], mood: "Bold & Daring" },
            { title: "Office Chic", items: [products[4], products[6]], mood: "Minimal & Smart" },
          ].map((look) => (
            <div key={look.title} className="rounded-2xl border border-border bg-card p-5 card-shadow hover:card-shadow-hover transition-shadow duration-300">
              <span className="font-sans text-xs uppercase tracking-wider text-secondary font-semibold">{look.mood}</span>
              <h3 className="font-serif text-xl text-foreground mt-1 mb-4">{look.title}</h3>
              <div className="grid grid-cols-2 gap-3">
                {look.items.map((p) => (
                  <Link key={p.id} to={`/product/${p.id}`} className="group rounded-xl overflow-hidden aspect-[3/4] bg-muted">
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </Link>
                ))}
              </div>
              <Link to="/shop" className="inline-flex items-center gap-1 mt-4 font-sans text-sm text-primary hover:underline">
                Shop This Look <ArrowRight size={14} />
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* New Arrivals */}
      <section className="bg-muted/40 py-16 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <span className="font-sans text-xs uppercase tracking-[0.3em] text-primary font-semibold">Just Landed</span>
            <h2 className="font-serif text-3xl lg:text-4xl text-foreground mt-2">New Arrivals</h2>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {newArrivals.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 lg:py-20">
        <div className="container mx-auto px-4 text-center max-w-xl">
          <span className="font-sans text-xs uppercase tracking-[0.3em] text-secondary font-semibold">Stay Connected</span>
          <h2 className="font-serif text-3xl text-foreground mt-2 mb-3">Join the AIC Community</h2>
          <p className="font-sans text-sm text-muted-foreground mb-8">
            Be the first to know about new drops, exclusive offers & style inspiration.
          </p>
          <form onSubmit={(e) => { e.preventDefault(); setEmail(""); }} className="flex gap-2">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your email address"
              className="flex-1 px-5 py-3.5 rounded-full border border-border bg-card font-sans text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
              required
            />
            <button type="submit" className="px-6 py-3.5 rounded-full gradient-primary text-primary-foreground font-sans text-sm font-semibold uppercase tracking-wider hover:scale-105 transition-all glow-orange">
              Subscribe
            </button>
          </form>
        </div>
      </section>

      <Footer />
      <StickyCart />
      <WhatsAppButton />
    </div>
  );
};

export default Index;
