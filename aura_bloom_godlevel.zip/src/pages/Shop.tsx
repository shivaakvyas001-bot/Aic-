import { useState, useMemo } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import StickyCart from "@/components/StickyCart";
import WhatsAppButton from "@/components/WhatsAppButton";
import { products } from "@/data/products";

const categories = ["All", "Women", "Men", "Accessories"];
const occasions = ["All", "Wedding", "Party", "Casual"];
const moods = ["All", "Elegant", "Bold", "Minimal"];
const sortOptions = [
  { label: "Newest", value: "newest" },
  { label: "Price: Low → High", value: "price-asc" },
  { label: "Price: High → Low", value: "price-desc" },
  { label: "Popular", value: "popular" },
];

const Shop = () => {
  const [category, setCategory] = useState("All");
  const [occasion, setOccasion] = useState("All");
  const [mood, setMood] = useState("All");
  const [sort, setSort] = useState("newest");
  const [showFilters, setShowFilters] = useState(false);

  const filtered = useMemo(() => {
    let result = [...products];
    if (category !== "All") result = result.filter((p) => p.category === category);
    if (occasion !== "All") result = result.filter((p) => p.occasion?.includes(occasion));
    if (mood !== "All") result = result.filter((p) => p.mood?.includes(mood));
    switch (sort) {
      case "price-asc": result.sort((a, b) => a.price - b.price); break;
      case "price-desc": result.sort((a, b) => b.price - a.price); break;
      case "popular": result.sort((a, b) => b.reviews - a.reviews); break;
      default: break;
    }
    return result;
  }, [category, occasion, mood, sort]);

  const activeFilters = [category, occasion, mood].filter(f => f !== "All").length;

  const FilterPanel = () => (
    <div className="space-y-6">
      {/* Category */}
      <div>
        <h4 className="font-sans text-xs uppercase tracking-widest text-foreground font-semibold mb-3">Category</h4>
        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`px-3 py-1.5 rounded-full font-sans text-xs transition-all ${
                category === c ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>
      {/* Occasion */}
      <div>
        <h4 className="font-sans text-xs uppercase tracking-widest text-foreground font-semibold mb-3">Occasion</h4>
        <div className="flex flex-wrap gap-2">
          {occasions.map((o) => (
            <button
              key={o}
              onClick={() => setOccasion(o)}
              className={`px-3 py-1.5 rounded-full font-sans text-xs transition-all ${
                occasion === o ? "bg-secondary text-secondary-foreground" : "bg-muted text-muted-foreground hover:text-foreground"
              }`}
            >
              {o}
            </button>
          ))}
        </div>
      </div>
      {/* Mood */}
      <div>
        <h4 className="font-sans text-xs uppercase tracking-widest text-foreground font-semibold mb-3">Mood</h4>
        <div className="flex flex-wrap gap-2">
          {moods.map((m) => (
            <button
              key={m}
              onClick={() => setMood(m)}
              className={`px-3 py-1.5 rounded-full font-sans text-xs transition-all ${
                mood === m ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground hover:text-foreground"
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container mx-auto px-4 py-8 lg:py-12">
        {/* Header */}
        <div className="text-center mb-10">
          <span className="font-sans text-xs uppercase tracking-[0.3em] text-primary font-semibold">Discover</span>
          <h1 className="font-serif text-4xl lg:text-5xl text-foreground mt-2">Shop</h1>
          <p className="font-sans text-sm text-muted-foreground mt-2">Curated fashion for every occasion & mood</p>
        </div>

        <div className="flex gap-8">
          {/* Desktop Sidebar Filters */}
          <div className="hidden lg:block w-60 flex-shrink-0">
            <div className="sticky top-32 p-5 rounded-2xl border border-border bg-card card-shadow">
              <h3 className="font-serif text-lg text-foreground mb-4">Filters</h3>
              <FilterPanel />
            </div>
          </div>

          <div className="flex-1">
            {/* Controls */}
            <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="font-sans text-sm text-muted-foreground">{filtered.length} products</span>
                {activeFilters > 0 && (
                  <button
                    onClick={() => { setCategory("All"); setOccasion("All"); setMood("All"); }}
                    className="flex items-center gap-1 px-3 py-1 rounded-full bg-primary/10 text-primary font-sans text-xs hover:bg-primary/20 transition-colors"
                  >
                    Clear filters ({activeFilters}) <X size={12} />
                  </button>
                )}
              </div>
              <div className="flex items-center gap-3">
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                  className="px-4 py-2 rounded-full border border-border bg-card font-sans text-xs uppercase tracking-wider focus:outline-none focus:ring-2 focus:ring-primary/30"
                >
                  {sortOptions.map((o) => (
                    <option key={o.value} value={o.value}>{o.label}</option>
                  ))}
                </select>
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="lg:hidden flex items-center gap-1.5 px-4 py-2 rounded-full border border-border font-sans text-xs uppercase tracking-wider hover:border-primary transition-colors"
                >
                  <SlidersHorizontal size={14} />
                  Filters {activeFilters > 0 && `(${activeFilters})`}
                </button>
              </div>
            </div>

            {/* Mobile filters */}
            {showFilters && (
              <div className="lg:hidden mb-6 p-5 rounded-2xl border border-border bg-card card-shadow animate-fade-in">
                <FilterPanel />
              </div>
            )}

            {/* Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-6">
              {filtered.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>

            {filtered.length === 0 && (
              <div className="text-center py-20">
                <p className="font-sans text-muted-foreground">No products found matching your filters.</p>
                <button
                  onClick={() => { setCategory("All"); setOccasion("All"); setMood("All"); }}
                  className="mt-4 font-sans text-sm text-primary hover:underline"
                >
                  Clear all filters
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
      <StickyCart />
      <WhatsAppButton />
    </div>
  );
};

export default Shop;
