import { useState } from "react";
import { Link } from "react-router-dom";
import { Minus, Plus, Trash2, ArrowLeft, ShoppingBag } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useCart } from "@/context/CartContext";

const Cart = () => {
  const { items, updateQuantity, removeItem, totalPrice } = useCart();
  const [coupon, setCoupon] = useState("");

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <ShoppingBag size={48} className="mx-auto text-muted-foreground/30 mb-4" />
          <h1 className="font-serif text-3xl text-foreground mb-2">Your Cart is Empty</h1>
          <p className="font-sans text-sm text-muted-foreground mb-8">Looks like you haven't added anything yet.</p>
          <Link to="/shop" className="inline-flex items-center gap-2 px-8 py-3.5 bg-primary text-primary-foreground font-sans text-sm font-semibold uppercase tracking-wider rounded-full hover:glow-pink transition-all">
            Start Shopping
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const shipping = totalPrice > 2999 ? 0 : 199;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container mx-auto px-4 py-8 lg:py-12">
        <Link to="/shop" className="inline-flex items-center gap-1.5 font-sans text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft size={16} /> Continue Shopping
        </Link>

        <h1 className="font-serif text-3xl lg:text-4xl text-foreground mb-8">Shopping Cart</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => (
              <div key={`${item.product.id}-${item.size}`} className="flex gap-4 p-4 rounded-xl border border-border bg-card card-shadow">
                <Link to={`/product/${item.product.id}`} className="w-24 h-28 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                  <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" loading="lazy" width={96} height={112} />
                </Link>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-sans text-sm font-medium text-foreground truncate">{item.product.name}</h3>
                      <p className="font-sans text-xs text-muted-foreground mt-0.5">Size: {item.size}</p>
                    </div>
                    <button onClick={() => removeItem(item.product.id, item.size)} className="text-muted-foreground hover:text-destructive transition-colors p-1">
                      <Trash2 size={16} />
                    </button>
                  </div>
                  <div className="flex items-center justify-between mt-4">
                    <div className="inline-flex items-center border border-border rounded-lg">
                      <button onClick={() => updateQuantity(item.product.id, item.size, item.quantity - 1)} className="p-2 text-muted-foreground hover:text-foreground transition-colors">
                        <Minus size={14} />
                      </button>
                      <span className="w-8 text-center font-sans text-xs font-medium">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.product.id, item.size, item.quantity + 1)} className="p-2 text-muted-foreground hover:text-foreground transition-colors">
                        <Plus size={14} />
                      </button>
                    </div>
                    <span className="font-sans text-sm font-semibold text-foreground">
                      ₹{(item.product.price * item.quantity).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-32 p-6 rounded-xl border border-border bg-card card-shadow">
              <h2 className="font-serif text-xl text-foreground mb-6">Order Summary</h2>

              <div className="space-y-3 font-sans text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span>₹{totalPrice.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? "Free" : `₹${shipping}`}</span>
                </div>
                {shipping > 0 && (
                  <p className="text-xs text-mint">Free shipping on orders over ₹2,999</p>
                )}
                <div className="border-t border-border pt-3 flex justify-between font-semibold text-foreground text-base">
                  <span>Total</span>
                  <span>₹{(totalPrice + shipping).toLocaleString()}</span>
                </div>
              </div>

              {/* Coupon */}
              <div className="mt-6 flex gap-2">
                <input
                  type="text"
                  value={coupon}
                  onChange={(e) => setCoupon(e.target.value)}
                  placeholder="Coupon code"
                  className="flex-1 px-4 py-2.5 rounded-lg border border-border bg-background font-sans text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
                <button className="px-4 py-2.5 rounded-lg border border-primary text-primary font-sans text-sm font-semibold hover:bg-primary hover:text-primary-foreground transition-colors">
                  Apply
                </button>
              </div>

              <button className="w-full mt-6 py-4 gradient-primary text-primary-foreground font-sans text-sm font-semibold uppercase tracking-wider rounded-full hover:scale-[1.02] transition-all glow-orange">
                Proceed to Checkout
              </button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Cart;
