import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Heart, Minus, Plus, Star, ShoppingBag, ArrowLeft, Sparkles } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import StickyCart from "@/components/StickyCart";
import WhatsAppButton from "@/components/WhatsAppButton";
import { products } from "@/data/products";
import { useCart } from "@/context/CartContext";
import { toast } from "sonner";

const ProductDetail = () => {
  const { id } = useParams();
  const product = products.find((p) => p.id === id);
  const { addItem } = useCart();
  const [selectedSize, setSelectedSize] = useState("");
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center">
          <p className="font-sans text-muted-foreground">Product not found.</p>
          <Link to="/shop" className="text-primary hover:underline mt-4 inline-block font-sans text-sm">Back to Shop</Link>
        </div>
        <Footer />
      </div>
    );
  }

  const related = products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);

  const handleAdd = () => {
    if (!selectedSize) {
      toast.error("Please select a size");
      return;
    }
    addItem(product, selectedSize, quantity);
    toast.success(`${product.name} added to cart`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container mx-auto px-4 py-6 lg:py-12">
        <Link to="/shop" className="inline-flex items-center gap-1.5 font-sans text-sm text-muted-foreground hover:text-foreground mb-6">
          <ArrowLeft size={16} /> Back to Shop
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16">
          {/* Image */}
          <div className="relative overflow-hidden rounded-xl bg-muted aspect-[3/4]">
            <img src={product.image} alt={product.name} className="w-full h-full object-cover" width={800} height={1024} />
            {product.isSale && (
              <span className="absolute top-4 left-4 bg-primary text-primary-foreground text-xs font-sans font-semibold uppercase tracking-wider px-3 py-1.5 rounded-full">
                Sale
              </span>
            )}
          </div>

          {/* Info */}
          <div className="flex flex-col justify-center">
            <p className="font-sans text-xs uppercase tracking-widest text-primary mb-2">{product.category}</p>
            <h1 className="font-serif text-3xl lg:text-4xl text-foreground">{product.name}</h1>

            <div className="flex items-center gap-2 mt-3">
              <div className="flex items-center gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={14} className={i < Math.round(product.rating) ? "fill-accent text-accent" : "text-border"} />
                ))}
              </div>
              <span className="font-sans text-xs text-muted-foreground">({product.reviews} reviews)</span>
            </div>

            <div className="flex items-center gap-3 mt-4">
              <span className="font-sans text-2xl font-bold text-foreground">₹{product.price.toLocaleString()}</span>
              {product.originalPrice && (
                <span className="font-sans text-lg text-muted-foreground line-through">₹{product.originalPrice.toLocaleString()}</span>
              )}
            </div>

            <p className="font-sans text-sm text-muted-foreground mt-4 leading-relaxed">{product.description}</p>

            {/* Size */}
            <div className="mt-8">
              <p className="font-sans text-xs uppercase tracking-widest text-foreground mb-3">Size</p>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((s) => (
                  <button
                    key={s}
                    onClick={() => setSelectedSize(s)}
                    className={`min-w-[3rem] px-4 py-2.5 rounded-lg border font-sans text-sm transition-all ${
                      selectedSize === s
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border text-foreground hover:border-primary/50"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div className="mt-6">
              <p className="font-sans text-xs uppercase tracking-widest text-foreground mb-3">Quantity</p>
              <div className="inline-flex items-center border border-border rounded-lg">
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="p-3 text-muted-foreground hover:text-foreground transition-colors">
                  <Minus size={16} />
                </button>
                <span className="w-12 text-center font-sans text-sm font-medium">{quantity}</span>
                <button onClick={() => setQuantity(quantity + 1)} className="p-3 text-muted-foreground hover:text-foreground transition-colors">
                  <Plus size={16} />
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 mt-8">
                <button
                  onClick={handleAdd}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-8 py-4 gradient-primary text-primary-foreground font-sans text-sm font-semibold uppercase tracking-wider rounded-full hover:scale-[1.02] transition-all glow-orange"
                >
                  <ShoppingBag size={18} />
                  Add to Cart
                </button>
                <button className="flex-1 inline-flex items-center justify-center gap-2 px-8 py-4 bg-secondary text-secondary-foreground font-sans text-sm font-semibold uppercase tracking-wider rounded-full hover:scale-[1.02] transition-all glow-purple">
                  Buy Now
                </button>
              <button className="w-14 h-14 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary transition-colors">
                <Heart size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Complete the Look */}
        {related.length > 0 && (
          <section className="mt-20 lg:mt-32">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={16} className="text-secondary" />
              <span className="font-sans text-xs uppercase tracking-[0.3em] text-secondary font-semibold">AI Styled</span>
            </div>
            <h2 className="font-serif text-2xl lg:text-3xl text-foreground mb-8">Complete The Look</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
              {related.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          </section>
        )}
      </div>

      <Footer />
      <StickyCart />
      <WhatsAppButton />
    </div>
  );
};

export default ProductDetail;
