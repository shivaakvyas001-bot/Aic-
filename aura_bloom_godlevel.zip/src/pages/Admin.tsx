import { useState, useMemo } from "react";
import {
  BarChart3, Package, Users, ShoppingCart, Plus, Edit, Trash2,
  TrendingUp, DollarSign, Eye, ArrowUpRight, ArrowDownRight,
  Image, Settings, LogOut, Menu, X, Search, ChevronDown
} from "lucide-react";
import { Link } from "react-router-dom";
import { products, Product } from "@/data/products";

type Tab = "dashboard" | "products" | "orders" | "users" | "banners" | "analytics";

interface Order {
  id: string;
  customer: string;
  email: string;
  total: number;
  status: "pending" | "processing" | "shipped" | "delivered";
  date: string;
  items: number;
}

interface Banner {
  id: string;
  title: string;
  status: "active" | "inactive";
  position: string;
}

const mockOrders: Order[] = [
  { id: "ORD-001", customer: "Priya Sharma", email: "priya@email.com", total: 2450, status: "delivered", date: "2026-04-06", items: 3 },
  { id: "ORD-002", customer: "Rahul Mehra", email: "rahul@email.com", total: 1890, status: "shipped", date: "2026-04-05", items: 2 },
  { id: "ORD-003", customer: "Ananya Gupta", email: "ananya@email.com", total: 5600, status: "processing", date: "2026-04-05", items: 4 },
  { id: "ORD-004", customer: "Vikram Singh", email: "vikram@email.com", total: 890, status: "pending", date: "2026-04-04", items: 1 },
  { id: "ORD-005", customer: "Meera Patel", email: "meera@email.com", total: 3200, status: "delivered", date: "2026-04-03", items: 2 },
];

const mockBanners: Banner[] = [
  { id: "1", title: "Summer Sale Banner", status: "active", position: "Homepage Hero" },
  { id: "2", title: "New Arrivals Promo", status: "active", position: "Homepage Middle" },
  { id: "3", title: "Free Shipping Banner", status: "inactive", position: "Top Bar" },
];

const mockUsers = [
  { id: "1", name: "Priya Sharma", email: "priya@email.com", orders: 5, spent: 12400, joined: "2026-01-15" },
  { id: "2", name: "Rahul Mehra", email: "rahul@email.com", orders: 3, spent: 8900, joined: "2026-02-20" },
  { id: "3", name: "Ananya Gupta", email: "ananya@email.com", orders: 8, spent: 22000, joined: "2025-11-10" },
  { id: "4", name: "Vikram Singh", email: "vikram@email.com", orders: 2, spent: 3400, joined: "2026-03-01" },
];

const statusColors: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-800",
  processing: "bg-blue-100 text-blue-800",
  shipped: "bg-purple-100 text-purple-800",
  delivered: "bg-green-100 text-green-800",
  active: "bg-green-100 text-green-800",
  inactive: "bg-gray-100 text-gray-600",
};

const Admin = () => {
  const [tab, setTab] = useState<Tab>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [orderStatusFilter, setOrderStatusFilter] = useState("all");

  const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: "dashboard", label: "Dashboard", icon: <BarChart3 size={18} /> },
    { key: "products", label: "Products", icon: <Package size={18} /> },
    { key: "orders", label: "Orders", icon: <ShoppingCart size={18} /> },
    { key: "users", label: "Users", icon: <Users size={18} /> },
    { key: "banners", label: "Banners", icon: <Image size={18} /> },
    { key: "analytics", label: "Analytics", icon: <TrendingUp size={18} /> },
  ];

  const filteredOrders = orderStatusFilter === "all"
    ? mockOrders
    : mockOrders.filter(o => o.status === orderStatusFilter);

  const stats = [
    { label: "Total Revenue", value: "₹4,52,000", change: "+12.5%", up: true, icon: <DollarSign size={20} /> },
    { label: "Total Orders", value: "1,247", change: "+8.2%", up: true, icon: <ShoppingCart size={20} /> },
    { label: "Total Users", value: "3,891", change: "+15.3%", up: true, icon: <Users size={20} /> },
    { label: "Page Views", value: "24.5K", change: "-2.1%", up: false, icon: <Eye size={20} /> },
  ];

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      <div className="p-6 border-b border-border">
        <Link to="/" className="font-serif text-2xl gradient-primary-text font-bold">AIC</Link>
        <p className="font-sans text-xs text-muted-foreground mt-1">Admin Panel</p>
      </div>
      <nav className="flex-1 p-4 space-y-1">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => { setTab(t.key); setSidebarOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-sans text-sm transition-all ${
              tab === t.key
                ? "bg-primary text-primary-foreground font-semibold"
                : "text-muted-foreground hover:bg-muted hover:text-foreground"
            }`}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </nav>
      <div className="p-4 border-t border-border">
        <Link to="/" className="flex items-center gap-3 px-4 py-3 rounded-xl font-sans text-sm text-muted-foreground hover:bg-muted hover:text-foreground transition-all">
          <LogOut size={18} />
          Back to Store
        </Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-muted/30 flex">
      {/* Desktop sidebar */}
      <aside className="hidden lg:block w-64 bg-card border-r border-border fixed inset-y-0 left-0 z-30">
        <SidebarContent />
      </aside>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-foreground/50" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute left-0 top-0 bottom-0 w-64 bg-card animate-slide-in-right">
            <SidebarContent />
          </aside>
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 lg:ml-64">
        {/* Top bar */}
        <header className="sticky top-0 z-20 bg-card/95 backdrop-blur-md border-b border-border px-4 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-foreground">
              <Menu size={22} />
            </button>
            <h1 className="font-serif text-xl lg:text-2xl text-foreground capitalize">{tab}</h1>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-full bg-muted">
              <Search size={16} className="text-muted-foreground" />
              <input
                type="text"
                placeholder="Search..."
                className="bg-transparent font-sans text-sm focus:outline-none w-40"
              />
            </div>
            <div className="w-9 h-9 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-sans text-sm font-bold">
              A
            </div>
          </div>
        </header>

        <div className="p-4 lg:p-8">
          {/* DASHBOARD */}
          {tab === "dashboard" && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {stats.map((s) => (
                  <div key={s.label} className="bg-card rounded-2xl p-5 border border-border card-shadow">
                    <div className="flex items-center justify-between mb-3">
                      <span className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">{s.icon}</span>
                      <span className={`flex items-center gap-1 font-sans text-xs font-semibold ${s.up ? "text-green-600" : "text-red-500"}`}>
                        {s.up ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                        {s.change}
                      </span>
                    </div>
                    <p className="font-sans text-2xl font-bold text-foreground">{s.value}</p>
                    <p className="font-sans text-xs text-muted-foreground mt-1">{s.label}</p>
                  </div>
                ))}
              </div>

              {/* Recent orders */}
              <div className="bg-card rounded-2xl border border-border card-shadow">
                <div className="p-5 border-b border-border flex items-center justify-between">
                  <h3 className="font-serif text-lg text-foreground">Recent Orders</h3>
                  <button onClick={() => setTab("orders")} className="font-sans text-xs text-primary hover:underline">View All</button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Order</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Customer</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Total</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Status</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockOrders.slice(0, 5).map((order) => (
                        <tr key={order.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                          <td className="px-5 py-4 font-sans text-sm font-medium text-foreground">{order.id}</td>
                          <td className="px-5 py-4 font-sans text-sm text-muted-foreground">{order.customer}</td>
                          <td className="px-5 py-4 font-sans text-sm font-medium text-foreground">₹{order.total.toLocaleString()}</td>
                          <td className="px-5 py-4">
                            <span className={`px-2.5 py-1 rounded-full font-sans text-xs font-medium capitalize ${statusColors[order.status]}`}>
                              {order.status}
                            </span>
                          </td>
                          <td className="px-5 py-4 font-sans text-sm text-muted-foreground">{order.date}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Quick stats */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
                  <h3 className="font-serif text-lg text-foreground mb-4">Top Products</h3>
                  <div className="space-y-3">
                    {products.slice(0, 4).map((p, i) => (
                      <div key={p.id} className="flex items-center gap-3">
                        <span className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center font-sans text-xs font-bold text-muted-foreground">
                          {i + 1}
                        </span>
                        <img src={p.image} alt={p.name} className="w-10 h-10 rounded-lg object-cover" />
                        <div className="flex-1 min-w-0">
                          <p className="font-sans text-sm text-foreground truncate">{p.name}</p>
                          <p className="font-sans text-xs text-muted-foreground">{p.reviews} sales</p>
                        </div>
                        <span className="font-sans text-sm font-semibold text-foreground">₹{p.price}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
                  <h3 className="font-serif text-lg text-foreground mb-4">Sales Overview</h3>
                  <div className="space-y-4">
                    {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, i) => {
                      const value = [65, 45, 80, 55, 90, 70, 85][i];
                      return (
                        <div key={day} className="flex items-center gap-3">
                          <span className="w-8 font-sans text-xs text-muted-foreground">{day}</span>
                          <div className="flex-1 h-3 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full gradient-primary rounded-full transition-all duration-500"
                              style={{ width: `${value}%` }}
                            />
                          </div>
                          <span className="w-8 font-sans text-xs text-muted-foreground text-right">{value}%</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* PRODUCTS */}
          {tab === "products" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <p className="font-sans text-sm text-muted-foreground">{products.length} products</p>
                <button
                  onClick={() => setShowAddProduct(true)}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-full gradient-primary text-primary-foreground font-sans text-sm font-semibold hover:scale-105 transition-all"
                >
                  <Plus size={16} /> Add Product
                </button>
              </div>

              <div className="bg-card rounded-2xl border border-border card-shadow overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Product</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Category</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Price</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Rating</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Status</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products.map((p) => (
                        <tr key={p.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-3">
                              <img src={p.image} alt={p.name} className="w-12 h-12 rounded-lg object-cover" />
                              <span className="font-sans text-sm font-medium text-foreground">{p.name}</span>
                            </div>
                          </td>
                          <td className="px-5 py-4 font-sans text-sm text-muted-foreground">{p.category}</td>
                          <td className="px-5 py-4 font-sans text-sm font-medium text-foreground">₹{p.price}</td>
                          <td className="px-5 py-4 font-sans text-sm text-muted-foreground">⭐ {p.rating}</td>
                          <td className="px-5 py-4">
                            <span className={`px-2.5 py-1 rounded-full font-sans text-xs font-medium ${p.isNew ? "bg-blue-100 text-blue-800" : p.isSale ? "bg-orange-100 text-orange-800" : "bg-green-100 text-green-800"}`}>
                              {p.isNew ? "New" : p.isSale ? "Sale" : "Active"}
                            </span>
                          </td>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-2">
                              <button className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors">
                                <Edit size={14} />
                              </button>
                              <button className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors">
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ORDERS */}
          {tab === "orders" && (
            <div className="space-y-6">
              <div className="flex items-center gap-2 flex-wrap">
                {["all", "pending", "processing", "shipped", "delivered"].map((s) => (
                  <button
                    key={s}
                    onClick={() => setOrderStatusFilter(s)}
                    className={`px-4 py-2 rounded-full font-sans text-xs capitalize transition-all ${
                      orderStatusFilter === s
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>

              <div className="bg-card rounded-2xl border border-border card-shadow overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Order ID</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Customer</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Items</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Total</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Status</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Date</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredOrders.map((order) => (
                        <tr key={order.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                          <td className="px-5 py-4 font-sans text-sm font-medium text-foreground">{order.id}</td>
                          <td className="px-5 py-4">
                            <div>
                              <p className="font-sans text-sm text-foreground">{order.customer}</p>
                              <p className="font-sans text-xs text-muted-foreground">{order.email}</p>
                            </div>
                          </td>
                          <td className="px-5 py-4 font-sans text-sm text-muted-foreground">{order.items}</td>
                          <td className="px-5 py-4 font-sans text-sm font-medium text-foreground">₹{order.total.toLocaleString()}</td>
                          <td className="px-5 py-4">
                            <select className={`px-2.5 py-1 rounded-full font-sans text-xs font-medium border-0 ${statusColors[order.status]}`}>
                              <option value="pending">Pending</option>
                              <option value="processing">Processing</option>
                              <option value="shipped">Shipped</option>
                              <option value="delivered">Delivered</option>
                            </select>
                          </td>
                          <td className="px-5 py-4 font-sans text-sm text-muted-foreground">{order.date}</td>
                          <td className="px-5 py-4">
                            <button className="font-sans text-xs text-primary hover:underline">View</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* USERS */}
          {tab === "users" && (
            <div className="space-y-6">
              <p className="font-sans text-sm text-muted-foreground">{mockUsers.length} registered users</p>

              <div className="bg-card rounded-2xl border border-border card-shadow overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">User</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Orders</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Total Spent</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Joined</th>
                        <th className="text-left px-5 py-3 font-sans text-xs uppercase tracking-wider text-muted-foreground">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockUsers.map((user) => (
                        <tr key={user.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-full bg-secondary/20 flex items-center justify-center font-sans text-sm font-bold text-secondary">
                                {user.name[0]}
                              </div>
                              <div>
                                <p className="font-sans text-sm font-medium text-foreground">{user.name}</p>
                                <p className="font-sans text-xs text-muted-foreground">{user.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-4 font-sans text-sm text-muted-foreground">{user.orders}</td>
                          <td className="px-5 py-4 font-sans text-sm font-medium text-foreground">₹{user.spent.toLocaleString()}</td>
                          <td className="px-5 py-4 font-sans text-sm text-muted-foreground">{user.joined}</td>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-2">
                              <button className="font-sans text-xs text-primary hover:underline">View</button>
                              <button className="font-sans text-xs text-destructive hover:underline">Ban</button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* BANNERS */}
          {tab === "banners" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <p className="font-sans text-sm text-muted-foreground">{mockBanners.length} banners</p>
                <button className="flex items-center gap-2 px-5 py-2.5 rounded-full gradient-primary text-primary-foreground font-sans text-sm font-semibold hover:scale-105 transition-all">
                  <Plus size={16} /> Add Banner
                </button>
              </div>

              <div className="grid gap-4">
                {mockBanners.map((banner) => (
                  <div key={banner.id} className="bg-card rounded-2xl border border-border p-5 card-shadow flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-10 rounded-lg gradient-primary" />
                      <div>
                        <p className="font-sans text-sm font-medium text-foreground">{banner.title}</p>
                        <p className="font-sans text-xs text-muted-foreground">{banner.position}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`px-2.5 py-1 rounded-full font-sans text-xs font-medium capitalize ${statusColors[banner.status]}`}>
                        {banner.status}
                      </span>
                      <button className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-muted-foreground hover:text-primary transition-colors">
                        <Edit size={14} />
                      </button>
                      <button className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center text-muted-foreground hover:text-destructive transition-colors">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ANALYTICS */}
          {tab === "analytics" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
                  <h3 className="font-sans text-xs uppercase tracking-wider text-muted-foreground mb-4">Monthly Revenue</h3>
                  <div className="space-y-3">
                    {["Jan", "Feb", "Mar", "Apr"].map((month, i) => {
                      const values = [72, 58, 85, 91];
                      return (
                        <div key={month} className="flex items-center gap-3">
                          <span className="w-8 font-sans text-xs text-muted-foreground">{month}</span>
                          <div className="flex-1 h-4 bg-muted rounded-full overflow-hidden">
                            <div className="h-full gradient-primary rounded-full" style={{ width: `${values[i]}%` }} />
                          </div>
                          <span className="w-10 font-sans text-xs text-muted-foreground text-right">₹{values[i]}K</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
                <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
                  <h3 className="font-sans text-xs uppercase tracking-wider text-muted-foreground mb-4">Traffic Sources</h3>
                  <div className="space-y-3">
                    {[
                      { source: "Direct", pct: 35 },
                      { source: "Google", pct: 28 },
                      { source: "Instagram", pct: 22 },
                      { source: "Other", pct: 15 },
                    ].map((s) => (
                      <div key={s.source} className="flex items-center gap-3">
                        <span className="w-16 font-sans text-xs text-muted-foreground">{s.source}</span>
                        <div className="flex-1 h-4 bg-muted rounded-full overflow-hidden">
                          <div className="h-full gradient-cool rounded-full" style={{ width: `${s.pct}%` }} />
                        </div>
                        <span className="w-8 font-sans text-xs text-muted-foreground text-right">{s.pct}%</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-card rounded-2xl border border-border p-5 card-shadow">
                  <h3 className="font-sans text-xs uppercase tracking-wider text-muted-foreground mb-4">Top Categories</h3>
                  <div className="space-y-3">
                    {[
                      { cat: "Women", pct: 45 },
                      { cat: "Men", pct: 30 },
                      { cat: "Accessories", pct: 25 },
                    ].map((c) => (
                      <div key={c.cat} className="flex items-center gap-3">
                        <span className="w-20 font-sans text-xs text-muted-foreground">{c.cat}</span>
                        <div className="flex-1 h-4 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-primary rounded-full" style={{ width: `${c.pct}%` }} />
                        </div>
                        <span className="w-8 font-sans text-xs text-muted-foreground text-right">{c.pct}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Conversion funnel */}
              <div className="bg-card rounded-2xl border border-border p-6 card-shadow">
                <h3 className="font-serif text-lg text-foreground mb-6">Conversion Funnel</h3>
                <div className="space-y-4">
                  {[
                    { stage: "Visitors", count: "24,500", pct: 100 },
                    { stage: "Product Views", count: "12,300", pct: 50 },
                    { stage: "Added to Cart", count: "4,100", pct: 17 },
                    { stage: "Checkout", count: "1,800", pct: 7 },
                    { stage: "Purchased", count: "1,247", pct: 5 },
                  ].map((f) => (
                    <div key={f.stage} className="flex items-center gap-4">
                      <span className="w-28 font-sans text-sm text-foreground">{f.stage}</span>
                      <div className="flex-1 h-6 bg-muted rounded-full overflow-hidden">
                        <div className="h-full gradient-primary rounded-full flex items-center justify-end pr-2" style={{ width: `${f.pct}%`, minWidth: "60px" }}>
                          <span className="font-sans text-[10px] font-bold text-primary-foreground">{f.count}</span>
                        </div>
                      </div>
                      <span className="w-10 font-sans text-xs text-muted-foreground text-right">{f.pct}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default Admin;
